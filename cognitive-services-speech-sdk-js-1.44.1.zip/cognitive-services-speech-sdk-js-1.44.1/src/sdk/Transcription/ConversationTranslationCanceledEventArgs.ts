// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.
// Multi-device Conversation is a Preview feature.

import { CancellationEventArgsBase } from "../CancellationEventArgsBase.js";

export class ConversationTranslationCanceledEventArgs extends CancellationEventArgsBase {
}
