// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.

import * as SpeechSDK from './distrib/lib/microsoft.cognitiveservices.speech.sdk.js';
window.SpeechSDK = SpeechSDK;
